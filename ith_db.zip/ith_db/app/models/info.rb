class Info < ApplicationRecord
end
