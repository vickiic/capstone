module InfosHelper
end
