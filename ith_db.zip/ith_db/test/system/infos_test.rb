require "application_system_test_case"

class InfosTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit infos_url
  #
  #   assert_selector "h1", text: "Info"
  # end
end
